import type { Record } from './types';

// ─── UID Generator ───
export const uid = (): string =>
  Date.now().toString(36) + Math.random().toString(36).slice(2);

// ─── Unique values from DB ───
export function uniq(db: Record[], key: keyof Record): string[] {
  return [...new Set(db.map((r) => String(r[key] ?? '')))]
    .filter(Boolean)
    .sort((a, b) =>
      isNaN(Number(a)) ? a.localeCompare(b) : Number(a) - Number(b)
    );
}

// ─── Initials from name ───
export function initials(name: string): string {
  return (name || '?')
    .split(' ')
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
}

// ─── Lower-is-better for a unit (e.g. time) ───
export function lowerIsBetter(unit: string): boolean {
  return /sec|s$|time|min|ms/.test((unit || '').toLowerCase());
}

// ─── Compare two values given a unit ───
export function isBetter(a: string, b: string, unit: string): boolean {
  const fa = parseFloat(a);
  const fb = parseFloat(b);
  if (isNaN(fa) || isNaN(fb)) return false;
  return lowerIsBetter(unit) ? fa < fb : fa > fb;
}

// ─── Escape single quotes for inline JS ───
export function esc(s: string): string {
  return (s || '').replace(/'/g, "\\'");
}

// ─── Format a numeric delta as HTML ───
export function fmtDelta(
  d: number,
  unit: string,
  bigger: boolean | null = null
): string {
  if (isNaN(d)) return '<span class="change-flat">—</span>';
  const improved =
    bigger !== null ? bigger : lowerIsBetter(unit) ? d < 0 : d > 0;
  const sign = d > 0 ? '+' : '';
  if (improved)
    return `<span class="change-up">▲ ${sign}${d.toFixed(2)}</span>`;
  if (d === 0) return `<span class="change-flat">—</span>`;
  return `<span class="change-down">▼ ${sign}${d.toFixed(2)}</span>`;
}

// ─── Rank badge HTML ───
export function rankBadge(r: string): string {
  const cls = r === '1' ? 'r1' : r === '2' ? 'r2' : r === '3' ? 'r3' : '';
  return `<span class="rank-badge ${cls}">#${r}</span>`;
}

// ─── Normalise imported rows to Record shape ───
export function normaliseRows(rows: Record<string, any>[]): Omit<Record, 'id'>[] {
  return rows
    .map((row) => {
      const find = (...keys: string[]) => {
        for (const k of keys) {
          const match = Object.keys(row).find(
            (rk) => rk.toLowerCase() === k.toLowerCase()
          );
          if (match !== undefined) return String(row[match] ?? '').trim();
        }
        return '';
      };
      return {
        athlete: find('athlete', 'name', 'player', 'competitor'),
        event: find('event', 'eventname', 'sport'),
        eventType: find('eventtype', 'type', 'category'),
        year: parseInt(find('year', 'season')) || new Date().getFullYear(),
        value: find('value', 'result', 'score', 'performance', 'time', 'distance'),
        unit: find('unit', 'units'),
        rank: find('rank', 'position', 'place'),
        venue: find('venue', 'location', 'stadium', 'ground'),
        notes: find('notes', 'note', 'remarks', 'comment'),
      };
    })
    .filter((r) => r.athlete && r.event && r.value);
}

// ─── Parse CSV text ───
export function parseCSV(text: string): Record<string, string>[] {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (!lines.length) return [];
  const headers = lines[0].split(',').map((h) => h.replace(/^"|"$/g, '').trim());
  return lines.slice(1).map((line) => {
    const vals = line.split(',').map((v) => v.replace(/^"|"$/g, '').trim());
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => (obj[h] = vals[i] ?? ''));
    return obj;
  });
}

// ─── Event logo fallback HTML ───
export function eventLogoFallbackHTML(evName: string, size = 40): string {
  const colors = [
    '#4f8ef8,#00e5c8',
    '#b06ef8,#ff5fb3',
    '#ff7c3e,#ffb800',
    '#00e676,#00c2b3',
    '#ff4f6a,#ff7c3e',
  ];
  const hash = evName.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const grad = colors[hash % colors.length];
  const [c1, c2] = grad.split(',');
  const letter = (evName[0] || 'E').toUpperCase();
  const r = Math.round(size * 0.2);
  const fs = Math.round(size * 0.4);
  return `<span style="display:inline-flex;align-items:center;justify-content:center;width:${size}px;height:${size}px;border-radius:${r}px;background:linear-gradient(135deg,${c1},${c2});font-size:${fs}px;font-weight:800;color:#fff;font-family:var(--font-head);vertical-align:middle;flex-shrink:0">${letter}</span>`;
}
