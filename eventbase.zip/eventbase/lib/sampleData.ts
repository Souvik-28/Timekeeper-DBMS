import type { Record } from './types';
import { uid } from './helpers';

export function getSampleData(): Record[] {
  return [
    { id: uid(), athlete: 'Arjun Mehta',   event: '100m Sprint', eventType: 'Track', year: 2022, value: '10.82', unit: 'sec', rank: '2', venue: 'Nehru Stadium',    notes: '' },
    { id: uid(), athlete: 'Arjun Mehta',   event: '100m Sprint', eventType: 'Track', year: 2023, value: '10.65', unit: 'sec', rank: '1', venue: 'Barasat Ground',   notes: 'Personal best' },
    { id: uid(), athlete: 'Arjun Mehta',   event: '100m Sprint', eventType: 'Track', year: 2024, value: '10.59', unit: 'sec', rank: '1', venue: 'Salt Lake Stadium', notes: 'District record' },
    { id: uid(), athlete: 'Arjun Mehta',   event: 'Long Jump',   eventType: 'Field', year: 2023, value: '7.12',  unit: 'm',   rank: '3', venue: 'Nehru Stadium',    notes: '' },
    { id: uid(), athlete: 'Arjun Mehta',   event: 'Long Jump',   eventType: 'Field', year: 2024, value: '7.28',  unit: 'm',   rank: '2', venue: 'Salt Lake Stadium', notes: '' },
    { id: uid(), athlete: 'Priya Das',     event: '100m Sprint', eventType: 'Track', year: 2022, value: '11.92', unit: 'sec', rank: '1', venue: 'Nehru Stadium',    notes: '' },
    { id: uid(), athlete: 'Priya Das',     event: '100m Sprint', eventType: 'Track', year: 2023, value: '11.74', unit: 'sec', rank: '1', venue: 'Barasat Ground',   notes: '' },
    { id: uid(), athlete: 'Priya Das',     event: '100m Sprint', eventType: 'Track', year: 2024, value: '11.68', unit: 'sec', rank: '1', venue: 'Salt Lake Stadium', notes: 'Season record' },
    { id: uid(), athlete: 'Priya Das',     event: '200m Sprint', eventType: 'Track', year: 2023, value: '24.31', unit: 'sec', rank: '2', venue: 'Salt Lake Stadium', notes: '' },
    { id: uid(), athlete: 'Priya Das',     event: '200m Sprint', eventType: 'Track', year: 2024, value: '24.11', unit: 'sec', rank: '1', venue: 'Burdwan',           notes: '' },
    { id: uid(), athlete: 'Ravi Kumar',    event: 'Shot Put',    eventType: 'Field', year: 2022, value: '14.20', unit: 'm',   rank: '1', venue: 'Burdwan',           notes: '' },
    { id: uid(), athlete: 'Ravi Kumar',    event: 'Shot Put',    eventType: 'Field', year: 2023, value: '14.85', unit: 'm',   rank: '1', venue: 'Asansol',           notes: '' },
    { id: uid(), athlete: 'Ravi Kumar',    event: 'Shot Put',    eventType: 'Field', year: 2024, value: '15.10', unit: 'm',   rank: '1', venue: 'Salt Lake Stadium', notes: 'Season best' },
    { id: uid(), athlete: 'Souvik Bose',   event: 'Long Jump',   eventType: 'Field', year: 2022, value: '6.88',  unit: 'm',   rank: '2', venue: 'Burdwan',           notes: '' },
    { id: uid(), athlete: 'Souvik Bose',   event: 'Long Jump',   eventType: 'Field', year: 2023, value: '6.95',  unit: 'm',   rank: '2', venue: 'Nehru Stadium',    notes: '' },
    { id: uid(), athlete: 'Souvik Bose',   event: 'Long Jump',   eventType: 'Field', year: 2024, value: '7.05',  unit: 'm',   rank: '1', venue: 'Salt Lake Stadium', notes: '' },
    { id: uid(), athlete: 'Meghna Roy',    event: '400m',        eventType: 'Track', year: 2023, value: '58.42', unit: 'sec', rank: '3', venue: 'Asansol',           notes: '' },
    { id: uid(), athlete: 'Meghna Roy',    event: '400m',        eventType: 'Track', year: 2024, value: '57.88', unit: 'sec', rank: '2', venue: 'Salt Lake Stadium', notes: 'PB' },
    { id: uid(), athlete: 'Debashis Pal',  event: 'Shot Put',    eventType: 'Field', year: 2022, value: '13.55', unit: 'm',   rank: '2', venue: 'Burdwan',           notes: '' },
    { id: uid(), athlete: 'Debashis Pal',  event: 'Shot Put',    eventType: 'Field', year: 2023, value: '13.90', unit: 'm',   rank: '2', venue: 'Asansol',           notes: '' },
    { id: uid(), athlete: 'Debashis Pal',  event: 'Shot Put',    eventType: 'Field', year: 2024, value: '13.75', unit: 'm',   rank: '3', venue: 'Salt Lake Stadium', notes: '' },
  ];
}
