// ─── Core Types ───

export interface Record {
  id: string;
  athlete: string;
  event: string;
  eventType: string;
  year: number;
  value: string;
  unit: string;
  rank: string;
  venue: string;
  notes: string;
}

export interface EventLogo {
  event: string;
  dataURL: string;
  color: string;
}

export interface ParticipantRecord {
  athlete: string;
  event: string;
  year: number;
  value?: string;
  unit?: string;
  rank?: string;
  venue?: string;
  notes?: string;
}

export type PanelName =
  | 'dashboard'
  | 'events'
  | 'athletes'
  | 'compare'
  | 'tally'
  | 'participant'
  | 'branding';

export interface PanelInfo {
  title: string;
  sub: string;
}

export interface ChartInstances {
  ev: any | null;
  seas: any | null;
  ath: any | null;
  types: any | null;
  cmp: any | null;
}

export type NotifType = 'success' | 'error' | 'info';
