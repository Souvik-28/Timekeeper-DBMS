/**
 * IndexedDB helpers for EventBase
 * Stores: 'records' (sport performance records) and 'logos' (event logo images)
 */

const DB_NAME = 'EventBaseDB';
const DB_VERSION = 1;

let idb: IDBDatabase | null = null;

// ─── Open / initialise the database ───
export function openIDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (idb) return resolve(idb);
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('records')) {
        db.createObjectStore('records', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('logos')) {
        db.createObjectStore('logos', { keyPath: 'event' });
      }
    };

    req.onsuccess = (e) => {
      idb = (e.target as IDBOpenDBRequest).result;
      resolve(idb);
    };

    req.onerror = (e) => {
      console.error('IDB open error', e);
      reject(e);
    };
  });
}

// ─── Get all records from a store ───
export function idbGetAll<T>(store: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    if (!idb) return resolve([]);
    const tx = idb.transaction(store, 'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = reject;
  });
}

// ─── Put (upsert) a single record ───
export function idbPut(store: string, value: object): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!idb) return resolve();
    const tx = idb.transaction(store, 'readwrite');
    tx.objectStore(store).put(value);
    tx.oncomplete = () => resolve();
    tx.onerror = reject;
  });
}

// ─── Put multiple records (batch) ───
export function idbPutAll(store: string, values: object[]): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!idb || !values.length) return resolve();
    const tx = idb.transaction(store, 'readwrite');
    const os = tx.objectStore(store);
    values.forEach((v) => os.put(v));
    tx.oncomplete = () => resolve();
    tx.onerror = reject;
  });
}

// ─── Delete a record by key ───
export function idbDelete(store: string, key: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!idb) return resolve();
    const tx = idb.transaction(store, 'readwrite');
    tx.objectStore(store).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = reject;
  });
}

// ─── Clear an entire store ───
export function idbClear(store: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!idb) return resolve();
    const tx = idb.transaction(store, 'readwrite');
    tx.objectStore(store).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = reject;
  });
}
