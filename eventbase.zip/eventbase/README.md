# EventBase — Sports Analytics Platform

A modern sports analytics platform for tracking athlete performance, managing records, and visualizing trends across seasons.

## Features

- 📊 **Dashboard** — Overview metrics, charts, and top performers
- 🏆 **All Records** — Browse, filter, and manage performance records
- 👤 **Athletes** — Athlete profiles with personal bests and progress charts
- 📈 **Year Compare** — Side-by-side season comparison
- 🔍 **Tally & Search** — Cross-year search and ranking
- 👥 **Participant Tally** — Multi-year participant tracking
- 🎨 **Event Logos & Branding** — Upload custom logos for each event

## Tech Stack

- [Next.js 14](https://nextjs.org/) — React framework
- [TypeScript](https://www.typescriptlang.org/) — Type safety
- [Chart.js](https://www.chartjs.org/) — Data visualizations
- [SheetJS (xlsx)](https://sheetjs.com/) — Excel/CSV import
- [IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API) — Local persistent storage

## Getting Started

```bash
# Install dependencies
pnpm install   # or npm install / yarn install

# Run the development server
pnpm dev

# Open http://localhost:3000
```

## Project Structure

```
eventbase/
├── app/                  # Next.js App Router
│   ├── layout.tsx        # Root layout
│   ├── page.tsx          # Home page (renders the main app)
│   └── globals.css       # Global styles & CSS variables
├── components/           # React components
│   ├── Sidebar.tsx       # Navigation sidebar
│   ├── Topbar.tsx        # Top navigation bar
│   ├── Dashboard.tsx     # Dashboard panel
│   ├── RecordsPanel.tsx  # All records panel
│   ├── AthletesPanel.tsx # Athletes panel
│   ├── ComparePanel.tsx  # Year compare panel
│   ├── TallyPanel.tsx    # Tally & search panel
│   ├── ParticipantPanel.tsx # Participant tally panel
│   ├── BrandingPanel.tsx # Event logos/branding panel
│   ├── AddRecordModal.tsx # Add record modal
│   ├── ImportModal.tsx   # Excel/CSV import modal
│   └── AthleteModal.tsx  # Athlete detail modal
├── lib/                  # Shared utilities
│   ├── db.ts             # IndexedDB helpers
│   ├── helpers.ts        # Pure utility functions
│   ├── types.ts          # TypeScript type definitions
│   └── sampleData.ts     # Sample data for demo
├── ai/                   # AI integrations (future)
│   └── index.ts
└── public/               # Static assets
    └── favicon.ico
```

## Import Format

Upload `.xlsx`, `.xls`, or `.csv` files with these columns:

| Column | Required | Description |
|--------|----------|-------------|
| Athlete | ✅ | Athlete / competitor name |
| Event | ✅ | Event name (e.g. 100m Sprint) |
| Year | ✅ | Season year (e.g. 2024) |
| Value | ✅ | Result / performance value |
| EventType | — | Track / Field / Swimming / etc. |
| Unit | — | sec / m / pts / kg |
| Rank | — | Position / rank |
| Venue | — | Venue name |
| Notes | — | Additional notes |

## License

MIT
