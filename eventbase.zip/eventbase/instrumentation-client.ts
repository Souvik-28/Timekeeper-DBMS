// Instrumentation for client-side monitoring
// Add your client-side telemetry setup here

export function register() {
  // e.g. Sentry.init({...})
}
