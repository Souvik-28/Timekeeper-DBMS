"use client";
/**
 * EventBase — Main Application Page
 * Wires together all panels, modals, and state management.
 * Uses IndexedDB for persistence via lib/db.ts helpers.
 */

import { useState, useEffect, useCallback } from "react";
import type { Record, EventLogo, PanelName } from "@/lib/types";
import { openIDB, idbGetAll, idbPut, idbPutAll, idbDelete, idbClear } from "@/lib/db";
import { getSampleData } from "@/lib/sampleData";
import { uid } from "@/lib/helpers";

// Components
import Sidebar         from "@/components/Sidebar";
import Topbar          from "@/components/Topbar";
import Dashboard       from "@/components/Dashboard";
import RecordsPanel    from "@/components/RecordsPanel";
import AthletesPanel   from "@/components/AthletesPanel";
import ComparePanel    from "@/components/ComparePanel";
import TallyPanel      from "@/components/TallyPanel";
import ParticipantPanel from "@/components/ParticipantPanel";
import BrandingPanel   from "@/components/BrandingPanel";
import AddRecordModal  from "@/components/AddRecordModal";
import ImportModal     from "@/components/ImportModal";
import AthleteModal    from "@/components/AthleteModal";

const PANEL_INFO: Record<PanelName, { title: string; sub: string }> = {
  dashboard:   { title: "Dashboard",        sub: "Overview" },
  events:      { title: "All Records",      sub: "Browse & manage" },
  athletes:    { title: "Athletes",         sub: "Profiles & PBs" },
  compare:     { title: "Year Compare",     sub: "Side-by-side seasons" },
  tally:       { title: "Tally & Search",   sub: "Cross-year search" },
  participant: { title: "Participant Tally",sub: "Multi-year tracking" },
  branding:    { title: "Event Logos",      sub: "Upload & manage event branding" },
};

export default function Home() {
  const [db, setDb]               = useState<Record[]>([]);
  const [logos, setLogos]         = useState<{ [ev: string]: { dataURL: string; color: string } }>({});
  const [panel, setPanel]         = useState<PanelName>("dashboard");
  const [dbOnline, setDbOnline]   = useState(false);
  const [notif, setNotif]         = useState<{ msg: string; type: string } | null>(null);
  const [addOpen, setAddOpen]     = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [viewAthlete, setViewAthlete] = useState<string | null>(null);

  // ── Notifications ──
  const showNotif = useCallback((msg: string, type = "success") => {
    setNotif({ msg, type });
    setTimeout(() => setNotif(null), 4000);
  }, []);

  // ── DB Init ──
  useEffect(() => {
    openIDB()
      .then(async () => {
        setDbOnline(true);
        const records = await idbGetAll<Record>("records");
        const logoArr = await idbGetAll<{ event: string; dataURL: string; color: string }>("logos");
        if (records.length) {
          setDb(records);
        } else {
          const sample = getSampleData();
          setDb(sample);
          await idbPutAll("records", sample);
        }
        const logoMap: typeof logos = {};
        logoArr.forEach((l) => (logoMap[l.event] = { dataURL: l.dataURL, color: l.color }));
        setLogos(logoMap);
      })
      .catch(() => {
        setDbOnline(false);
        setDb(getSampleData());
      });
  }, []);

  // ── Record Actions ──
  const handleAddRecord = async (record: Record) => {
    setDb((prev) => [...prev, record]);
    await idbPut("records", record);
    showNotif("✓ Record added & saved!");
  };

  const handleImport = async (records: Record[]) => {
    setDb((prev) => [...prev, ...records]);
    await idbPutAll("records", records);
    showNotif(`✓ ${records.length} records imported!`);
  };

  const handleDelete = async (id: string) => {
    setDb((prev) => prev.filter((r) => r.id !== id));
    await idbDelete("records", id);
    showNotif("Record deleted.", "error");
  };

  // ── Logo Actions ──
  const handleSaveLogo = async (event: string, dataURL: string, color: string) => {
    setLogos((prev) => ({ ...prev, [event]: { dataURL, color } }));
    await idbPut("logos", { event, dataURL, color });
    showNotif(`✓ Logo saved for "${event}"!`);
  };

  const handleDeleteLogo = async (event: string) => {
    setLogos((prev) => { const n = { ...prev }; delete n[event]; return n; });
    await idbDelete("logos", event);
    showNotif(`Logo removed for "${event}"`);
  };

  // ── Clear All ──
  const handleClearAll = async () => {
    if (!confirm("This will delete ALL records and logos. Are you sure?")) return;
    if (!confirm("Are you really sure? This cannot be undone.")) return;
    await idbClear("records");
    await idbClear("logos");
    setDb([]);
    setLogos({});
    showNotif("All data cleared.", "error");
  };

  const info = PANEL_INFO[panel];

  return (
    <>
      <div className="layout">
        <Sidebar
          activePanel={panel}
          recordCount={db.length}
          logoCount={Object.keys(logos).length}
          athleteCount={[...new Set(db.map((r) => r.athlete))].length}
          onNavigate={(p) => setPanel(p as PanelName)}
        />

        <main className="main">
          <Topbar
            title={info.title}
            subtitle={info.sub}
            dbOnline={dbOnline}
            onAddRecord={() => setAddOpen(true)}
            onImport={() => setImportOpen(true)}
            onClearAll={handleClearAll}
          />

          <div className="content">
            {panel === "dashboard"   && <Dashboard    db={db} onViewAthlete={setViewAthlete} />}
            {panel === "events"      && <RecordsPanel db={db} eventLogos={logos} onDelete={handleDelete} onViewAthlete={setViewAthlete} />}
            {panel === "athletes"    && <AthletesPanel db={db} eventLogos={logos} onViewAthlete={setViewAthlete} />}
            {panel === "compare"     && <ComparePanel  db={db} />}
            {panel === "tally"       && <TallyPanel    db={db} onViewAthlete={setViewAthlete} />}
            {panel === "participant" && <ParticipantPanel db={db} />}
            {panel === "branding"    && <BrandingPanel db={db} eventLogos={logos} onSaveLogo={handleSaveLogo} onDeleteLogo={handleDeleteLogo} />}
          </div>
        </main>
      </div>

      {/* Modals */}
      <AddRecordModal  open={addOpen}    onClose={() => setAddOpen(false)}    onSave={handleAddRecord} />
      <ImportModal     open={importOpen} onClose={() => setImportOpen(false)} onImport={handleImport} />
      <AthleteModal    open={!!viewAthlete} athlete={viewAthlete} db={db} onClose={() => setViewAthlete(null)} />

      {/* Notification toast */}
      {notif && (
        <div className={`notif show notif-${notif.type}`} dangerouslySetInnerHTML={{ __html: notif.msg }} />
      )}
    </>
  );
}
