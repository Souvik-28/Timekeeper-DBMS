"use client";
/**
 * AddRecordModal — Modal for adding a single performance record.
 */

import { useState } from "react";
import type { Record } from "@/lib/types";
import { uid } from "@/lib/helpers";

interface AddRecordModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (record: Record) => void;
}

const EVENT_TYPES = [
  "Track", "Field", "Swimming", "Cycling",
  "Football", "Cricket", "Kabaddi", "Wrestling", "Boxing", "Other",
];

export default function AddRecordModal({ open, onClose, onSave }: AddRecordModalProps) {
  const [form, setForm] = useState({
    athlete: "", event: "", eventType: "Track",
    year: String(new Date().getFullYear()),
    value: "", unit: "", rank: "", venue: "", notes: "",
  });
  const [error, setError] = useState("");

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSave = () => {
    if (!form.athlete || !form.event || !form.year || !form.value) {
      setError("Fill all required fields");
      return;
    }
    setError("");
    onSave({
      id: uid(),
      athlete: form.athlete.trim(),
      event: form.event.trim(),
      eventType: form.eventType,
      year: parseInt(form.year),
      value: form.value.trim(),
      unit: form.unit.trim(),
      rank: form.rank.trim(),
      venue: form.venue.trim(),
      notes: form.notes.trim(),
    });
    setForm({ athlete: "", event: "", eventType: "Track", year: String(new Date().getFullYear()), value: "", unit: "", rank: "", venue: "", notes: "" });
    onClose();
  };

  if (!open) return null;

  return (
    <div className="modal-overlay open" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box">
        <div className="modal-head">
          <div>
            <h2>Add New Record</h2>
            <p>Enter athlete performance data</p>
          </div>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        {error && <div style={{ color: "var(--red)", fontSize: 12, marginBottom: 10 }}>{error}</div>}

        <div className="form-grid">
          <div className="form-row">
            <label>Athlete / Competitor <span className="req">*</span></label>
            <input type="text" value={form.athlete} onChange={set("athlete")} placeholder="e.g. Rohit Sharma" />
          </div>
          <div className="form-row">
            <label>Event Name <span className="req">*</span></label>
            <input type="text" value={form.event} onChange={set("event")} placeholder="e.g. 100m Sprint" />
          </div>
          <div className="form-row">
            <label>Event Type</label>
            <select value={form.eventType} onChange={set("eventType")}>
              {EVENT_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="form-row">
            <label>Season / Year <span className="req">*</span></label>
            <input type="number" value={form.year} onChange={set("year")} placeholder="e.g. 2024" />
          </div>
          <div className="form-row">
            <label>Result / Value <span className="req">*</span></label>
            <input type="text" value={form.value} onChange={set("value")} placeholder="e.g. 10.52" />
          </div>
          <div className="form-row">
            <label>Unit</label>
            <input type="text" value={form.unit} onChange={set("unit")} placeholder="sec / m / pts / kg" />
          </div>
          <div className="form-row">
            <label>Rank / Position</label>
            <input type="number" value={form.rank} onChange={set("rank")} placeholder="e.g. 1" />
          </div>
          <div className="form-row">
            <label>Venue</label>
            <input type="text" value={form.venue} onChange={set("venue")} placeholder="e.g. Nehru Stadium" />
          </div>
        </div>

        <div className="form-row" style={{ marginTop: 12 }}>
          <label>Notes</label>
          <textarea rows={2} value={form.notes} onChange={set("notes")} placeholder="Any additional notes..." />
        </div>

        <hr />
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSave}>Save Record</button>
        </div>
      </div>
    </div>
  );
}
