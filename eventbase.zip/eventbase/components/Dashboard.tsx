"use client";
/**
 * Dashboard — Overview panel showing metrics, charts, and top performers.
 * Uses Chart.js for bar, line, and doughnut charts.
 */

import { useEffect, useRef } from "react";
import type { Record } from "@/lib/types";
import { uniq, esc, isBetter, eventLogoFallbackHTML, rankBadge } from "@/lib/helpers";

interface DashboardProps {
  db: Record[];
  onViewAthlete: (name: string) => void;
}

export default function Dashboard({ db, onViewAthlete }: DashboardProps) {
  const chartEv   = useRef<any>(null);
  const chartSeas = useRef<any>(null);
  const chartTypes= useRef<any>(null);

  const athletes = uniq(db, "athlete");
  const events   = uniq(db, "event");
  const years    = uniq(db, "year");

  useEffect(() => {
    const Chart = (window as any).Chart;
    if (!Chart || !db.length) return;

    // Event bar chart
    const evCounts: Record<string, number> = {};
    db.forEach((r) => (evCounts[r.event] = (evCounts[r.event] || 0) + 1));
    const evLabels = Object.keys(evCounts).sort((a, b) => evCounts[b] - evCounts[a]).slice(0, 8);
    const evData   = evLabels.map((e) => evCounts[e]);
    const colors   = ["#4f8ef8","#00e5c8","#ffb800","#00e676","#b06ef8","#ff5fb3","#ff4f6a","#ff7c3e"];

    if (chartEv.current)   chartEv.current.destroy();
    const evCtx = (document.getElementById("chart-events") as HTMLCanvasElement)?.getContext("2d");
    if (evCtx) chartEv.current = new Chart(evCtx, {
      type: "bar",
      data: { labels: evLabels, datasets: [{ data: evData, backgroundColor: evLabels.map((_, i) => colors[i % 8]), borderRadius: 6, borderSkipped: false }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: "#7d88a0", font: { size: 10 } }, grid: { color: "rgba(255,255,255,0.03)" } }, y: { ticks: { color: "#7d88a0", stepSize: 1, font: { size: 10 } }, grid: { color: "rgba(255,255,255,0.04)" }, beginAtZero: true } } },
    });

    // Season line chart
    const seaCounts: Record<string, number> = {};
    db.forEach((r) => (seaCounts[r.year] = (seaCounts[r.year] || 0) + 1));
    const seaYears = Object.keys(seaCounts).sort((a, b) => Number(a) - Number(b));
    if (chartSeas.current) chartSeas.current.destroy();
    const seasCtx = (document.getElementById("chart-seasons") as HTMLCanvasElement)?.getContext("2d");
    if (seasCtx) chartSeas.current = new Chart(seasCtx, {
      type: "line",
      data: { labels: seaYears, datasets: [{ data: seaYears.map((y) => seaCounts[y]), borderColor: "#00e5c8", backgroundColor: "rgba(0,229,200,0.08)", fill: true, tension: 0.4, pointRadius: 5, pointBackgroundColor: "#00e5c8", pointBorderColor: "#080c16", pointBorderWidth: 2 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: "#7d88a0", font: { size: 10 } }, grid: { color: "rgba(255,255,255,0.03)" } }, y: { ticks: { color: "#7d88a0", stepSize: 1, font: { size: 10 } }, grid: { color: "rgba(255,255,255,0.04)" }, beginAtZero: true } } },
    });

    // Event type donut
    const typeCounts: Record<string, number> = {};
    db.forEach((r) => (typeCounts[r.eventType || "Other"] = (typeCounts[r.eventType || "Other"] || 0) + 1));
    const typeLabels = Object.keys(typeCounts);
    const typeColors = ["#4f8ef8","#00e5c8","#ffb800","#00e676","#b06ef8","#ff5fb3","#ff4f6a"];
    if (chartTypes.current) chartTypes.current.destroy();
    const typeCtx = (document.getElementById("chart-types") as HTMLCanvasElement)?.getContext("2d");
    if (typeCtx && typeLabels.length) chartTypes.current = new Chart(typeCtx, {
      type: "doughnut",
      data: { labels: typeLabels, datasets: [{ data: typeLabels.map((t) => typeCounts[t]), backgroundColor: typeColors.slice(0, typeLabels.length), borderWidth: 0, hoverOffset: 6 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: "65%", plugins: { legend: { position: "right", labels: { color: "#7d88a0", font: { size: 11 }, boxWidth: 10, padding: 8 } } } },
    });

    return () => {
      chartEv.current?.destroy();
      chartSeas.current?.destroy();
      chartTypes.current?.destroy();
    };
  }, [db]);

  // Top athletes
  const athCounts: Record<string, number> = {};
  db.forEach((r) => (athCounts[r.athlete] = (athCounts[r.athlete] || 0) + 1));
  const topAths = Object.entries(athCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const maxRecs = topAths[0]?.[1] || 1;
  const gradColors = ["var(--grad-main)","var(--grad-purple)","var(--grad-warm)","var(--grad-green)","linear-gradient(135deg,#ff4f6a,#ff7c3e)"];

  // Recent records
  const recent = [...db].sort((a, b) => b.year - a.year).slice(0, 5);

  if (!db.length) {
    return (
      <div className="empty" style={{ padding: "80px 20px" }}>
        <div className="empty-icon">🏆</div>
        <h3>No data yet</h3>
        <p>Add records or load sample data to get started.</p>
      </div>
    );
  }

  return (
    <>
      <div className="metrics-row">
        <div className="metric-card c1">
          <div className="metric-glow" />
          <div className="mval">{db.length}</div>
          <div className="mlbl">Total Records</div>
          <div className="mtrend">{years.length} season{years.length !== 1 ? "s" : ""}</div>
        </div>
        <div className="metric-card c2">
          <div className="metric-glow" />
          <div className="mval">{athletes.length}</div>
          <div className="mlbl">Athletes</div>
          <div className="mtrend">Across all events</div>
        </div>
        <div className="metric-card c3">
          <div className="metric-glow" />
          <div className="mval">{events.length}</div>
          <div className="mlbl">Events</div>
          <div className="mtrend">Disciplines tracked</div>
        </div>
        <div className="metric-card c4">
          <div className="metric-glow" />
          <div className="mval">{years.length}</div>
          <div className="mlbl">Seasons</div>
          <div className="mtrend">{years[0]} – {years[years.length - 1]}</div>
        </div>
      </div>

      <div className="charts-row">
        <div className="card">
          <div className="card-header">
            <div className="card-title">Records by Event</div>
          </div>
          <div className="chart-wrap"><canvas id="chart-events" /></div>
        </div>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Records by Season</div>
          </div>
          <div className="chart-wrap"><canvas id="chart-seasons" /></div>
        </div>
      </div>

      <div className="charts-row">
        <div className="card">
          <div className="card-header"><div className="card-title">Top Athletes</div></div>
          <div id="dash-top-athletes">
            {topAths.map(([name, count], i) => (
              <div key={name} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8, cursor: "pointer" }} onClick={() => onViewAthlete(name)}>
                <div className={`rank-badge ${i < 3 ? "r" + (i + 1) : ""}`}>{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: "var(--text)" }}>{name}</div>
                  <div className="progress-bar-wrap">
                    <div className="progress-bar" style={{ width: `${Math.round((count / maxRecs) * 100)}%`, background: gradColors[i % 5] }} />
                  </div>
                </div>
                <div style={{ fontSize: 11, color: "var(--text3)", minWidth: 50, textAlign: "right" }}>{count} record{count !== 1 ? "s" : ""}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <div className="card-header"><div className="card-title">Event Types</div></div>
          <div className="chart-wrap"><canvas id="chart-types" /></div>
        </div>
      </div>

      {recent.length > 0 && (
        <div className="card">
          <div className="card-header"><div className="card-title">Recent Records</div></div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Athlete</th><th>Event</th><th>Year</th><th>Value</th><th>Unit</th><th>Rank</th><th>Venue</th></tr></thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id}>
                    <td className="td-athlete" onClick={() => onViewAthlete(r.athlete)}>{r.athlete}</td>
                    <td>{r.event}</td>
                    <td><span className="year-chip">{r.year}</span></td>
                    <td><strong>{r.value}</strong></td>
                    <td>{r.unit || "—"}</td>
                    <td dangerouslySetInnerHTML={{ __html: r.rank ? rankBadge(r.rank) : "—" }} />
                    <td style={{ color: "var(--text2)" }}>{r.venue || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
}
