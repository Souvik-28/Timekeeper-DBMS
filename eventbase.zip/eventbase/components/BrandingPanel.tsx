"use client";
/**
 * BrandingPanel — Upload and manage event logos/branding.
 */

import { useState, useRef } from "react";
import type { Record } from "@/lib/types";

interface BrandingPanelProps {
  db: Record[];
  eventLogos: Record<string, { dataURL: string; color: string }>;
  onSaveLogo: (event: string, dataURL: string, color: string) => void;
  onDeleteLogo: (event: string) => void;
}

const LOGO_COLORS = [
  { label: "Blue–Cyan",   value: "#4f8ef8,#00e5c8" },
  { label: "Purple–Pink", value: "#b06ef8,#ff5fb3" },
  { label: "Warm",        value: "#ff7c3e,#ffb800" },
  { label: "Green",       value: "#00e676,#00c2b3" },
];

export default function BrandingPanel({ db, eventLogos, onSaveLogo, onDeleteLogo }: BrandingPanelProps) {
  const [modalOpen, setModalOpen]       = useState(false);
  const [selectedEvent, setSelectedEvent] = useState("");
  const [pendingData, setPendingData]   = useState<string | null>(null);
  const [color, setColor]               = useState(LOGO_COLORS[0].value);
  const [dragging, setDragging]         = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const events = [...new Set(db.map((r) => r.event))].sort();

  const handleFile = (file: File) => {
    if (file.size > 2 * 1024 * 1024) { alert("File too large — max 2MB"); return; }
    const reader = new FileReader();
    reader.onload = (e) => setPendingData(e.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!selectedEvent) { alert("Please select an event"); return; }
    if (!pendingData)   { alert("Please choose a logo image"); return; }
    onSaveLogo(selectedEvent, pendingData, color);
    setModalOpen(false);
    setPendingData(null);
  };

  const fallbackBadge = (evName: string, size = 56) => {
    const colors = ["#4f8ef8,#00e5c8","#b06ef8,#ff5fb3","#ff7c3e,#ffb800","#00e676,#00c2b3","#ff4f6a,#ff7c3e"];
    const hash = evName.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
    const grad = colors[hash % colors.length];
    const [c1, c2] = grad.split(",");
    const letter = (evName[0] || "E").toUpperCase();
    return `<span style="display:inline-flex;align-items:center;justify-content:center;width:${size}px;height:${size}px;border-radius:${Math.round(size*0.2)}px;background:linear-gradient(135deg,${c1},${c2});font-size:${Math.round(size*0.4)}px;font-weight:800;color:#fff;font-family:var(--font-head)">${letter}</span>`;
  };

  return (
    <>
      <div style={{ background: "linear-gradient(135deg,rgba(0,229,200,0.08),rgba(176,110,248,0.06))", border: "1px solid rgba(0,229,200,0.18)", borderRadius: "var(--r2)", padding: 18, marginBottom: 18 }}>
        <div style={{ fontFamily: "var(--font-head)", fontSize: 15, fontWeight: 700, marginBottom: 6 }}>🎨 Event Logos & Branding</div>
        <p style={{ fontSize: 12, color: "var(--text2)", lineHeight: 1.7, marginBottom: 12 }}>
          Add a custom logo to each event. Logos appear across the platform — on dashboards, athlete profiles, and participant cards.
        </p>
        <button className="btn btn-primary" onClick={() => setModalOpen(true)}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
          Upload Event Logo
        </button>
      </div>

      {events.length === 0 ? (
        <div className="empty"><div className="empty-icon">🏅</div><h3>No events yet</h3><p>Add records first, then upload logos here.</p></div>
      ) : (
        <div className="event-logo-grid">
          {events.map((ev) => {
            const logo = eventLogos[ev];
            const types = [...new Set(db.filter((r) => r.event === ev).map((r) => r.eventType || ""))].filter(Boolean).join(", ");
            const count = db.filter((r) => r.event === ev).length;
            return (
              <div key={ev} className={`event-logo-card ${logo ? "has-logo" : ""}`} onClick={() => { setSelectedEvent(ev); setModalOpen(true); }}>
                {logo
                  ? <div style={{ width: 72, height: 72, margin: "0 auto 8px", display: "flex", alignItems: "center", justifyContent: "center" }}><img src={logo.dataURL} style={{ width: 72, height: 72, objectFit: "contain", borderRadius: 12 }} alt={ev} /></div>
                  : <div className="event-logo-img" dangerouslySetInnerHTML={{ __html: fallbackBadge(ev, 56) }} />
                }
                <div className="event-logo-name">{ev}</div>
                <div className="event-logo-type">{types || "Other"} · {count} record{count !== 1 ? "s" : ""}</div>
                <div className="event-logo-actions" onClick={(e) => e.stopPropagation()}>
                  {logo
                    ? <>
                        <button className="btn btn-ghost btn-sm" onClick={() => { setSelectedEvent(ev); setModalOpen(true); }}>Change</button>
                        <button className="btn btn-danger btn-sm" onClick={() => onDeleteLogo(ev)}>Remove</button>
                      </>
                    : <button className="btn btn-primary btn-sm" onClick={() => { setSelectedEvent(ev); setModalOpen(true); }}>+ Logo</button>
                  }
                </div>
                <div className="logo-upload-hint">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  <span>{logo ? "Change" : "Upload"} Logo</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload Modal */}
      {modalOpen && (
        <div className="modal-overlay open" onClick={(e) => e.target === e.currentTarget && setModalOpen(false)}>
          <div className="modal-box">
            <div className="modal-head">
              <div><h2>Upload Event Logo</h2><p>PNG, JPG, SVG, WebP · Max 2MB</p></div>
              <button className="modal-close" onClick={() => setModalOpen(false)}>×</button>
            </div>

            <div className="form-row" style={{ marginBottom: 14 }}>
              <label>Event</label>
              <select value={selectedEvent} onChange={(e) => setSelectedEvent(e.target.value)}>
                <option value="">— choose an event —</option>
                {events.map((ev) => <option key={ev} value={ev}>{ev}</option>)}
              </select>
            </div>

            <div
              className={`upload-zone ${dragging ? "drag" : ""}`}
              style={{ marginBottom: 14 }}
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            >
              {pendingData
                ? <><img src={pendingData} style={{ maxHeight: 120, maxWidth: 200, borderRadius: 10, objectFit: "contain" }} alt="preview" /><p style={{ marginTop: 8, fontSize: 11, color: "var(--green)" }}>✓ Ready to save</p></>
                : <><div className="uz-icon">🖼️</div><h3>Click to choose logo image</h3><p>PNG, JPG, SVG, WebP · Max 2MB</p></>
              }
            </div>

            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />

            <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
              {LOGO_COLORS.map((c) => (
                <button
                  key={c.value}
                  onClick={() => setColor(c.value)}
                  style={{ width: 28, height: 28, borderRadius: 6, background: `linear-gradient(135deg,${c.value.split(",")[0]},${c.value.split(",")[1]})`, border: color === c.value ? "2px solid white" : "2px solid transparent", cursor: "pointer" }}
                  title={c.label}
                />
              ))}
            </div>

            <hr />
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setModalOpen(false)}>Cancel</button>
              {pendingData && <button className="btn btn-primary" onClick={handleSave}>Save Logo</button>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
