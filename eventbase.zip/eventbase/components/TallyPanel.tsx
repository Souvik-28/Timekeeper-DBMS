"use client";
/**
 * TallyPanel — Cross-year search and ranking by event.
 */

import { useState } from "react";
import type { Record } from "@/lib/types";
import { uniq, rankBadge } from "@/lib/helpers";

interface TallyPanelProps { db: Record[]; onViewAthlete: (name: string) => void; }

export default function TallyPanel({ db, onViewAthlete }: TallyPanelProps) {
  const [search, setSearch] = useState("");
  const [ev, setEv]         = useState("");
  const events = uniq(db, "event");
  const q = search.toLowerCase();
  const rows = db.filter(
    (r) => (!q || r.athlete.toLowerCase().includes(q) || r.event.toLowerCase().includes(q)) && (!ev || r.event === ev)
  ).sort((a, b) => a.event.localeCompare(b.event) || a.year - b.year);

  return (
    <>
      <div className="search-row">
        <div className="search-wrap">
          <svg className="si" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input type="text" placeholder="Search athlete or event..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select value={ev} onChange={(e) => setEv(e.target.value)}>
          <option value="">All events</option>
          {events.map((e) => <option key={e} value={e}>{e}</option>)}
        </select>
      </div>
      {rows.length === 0 ? (
        <div className="empty"><div className="empty-icon">🔍</div><h3>No results</h3><p>Try a different search or event filter.</p></div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Athlete</th><th>Event</th><th>Year</th><th>Value</th><th>Unit</th><th>Rank</th><th>Venue</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="td-athlete" onClick={() => onViewAthlete(r.athlete)}>{r.athlete}</td>
                  <td>{r.event}</td>
                  <td><span className="year-chip">{r.year}</span></td>
                  <td><strong>{r.value}</strong></td>
                  <td>{r.unit || "—"}</td>
                  <td dangerouslySetInnerHTML={{ __html: r.rank ? rankBadge(r.rank) : "—" }} />
                  <td style={{ color: "var(--text2)" }}>{r.venue || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
