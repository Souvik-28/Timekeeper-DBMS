"use client";
/**
 * ComparePanel — Side-by-side comparison of two athletes or two seasons.
 */

import { useState, useEffect, useRef } from "react";
import type { Record } from "@/lib/types";
import { uniq, isBetter, fmtDelta } from "@/lib/helpers";

interface ComparePanelProps { db: Record[]; }

export default function ComparePanel({ db }: ComparePanelProps) {
  const [ath1, setAth1] = useState("");
  const [ath2, setAth2] = useState("");
  const [ev, setEv]     = useState("");
  const chartRef = useRef<any>(null);

  const athletes = uniq(db, "athlete");
  const events   = uniq(db, "event");

  useEffect(() => {
    if (!ath1 || !ath2 || !ev) return;
    const Chart = (window as any).Chart;
    if (!Chart) return;
    const r1 = db.filter((r) => r.athlete === ath1 && r.event === ev).sort((a, b) => a.year - b.year);
    const r2 = db.filter((r) => r.athlete === ath2 && r.event === ev).sort((a, b) => a.year - b.year);
    const allYears = [...new Set([...r1, ...r2].map((r) => r.year))].sort((a, b) => a - b);
    if (chartRef.current) chartRef.current.destroy();
    const canvas = document.getElementById("cmp-chart") as HTMLCanvasElement;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    chartRef.current = new Chart(ctx, {
      type: "line",
      data: {
        labels: allYears,
        datasets: [
          { label: ath1, data: allYears.map((y) => parseFloat(r1.find((r) => r.year === y)?.value || "") || null), borderColor: "#4f8ef8", backgroundColor: "rgba(79,142,248,0.1)", fill: false, tension: 0.4, pointRadius: 5, pointBackgroundColor: "#4f8ef8" },
          { label: ath2, data: allYears.map((y) => parseFloat(r2.find((r) => r.year === y)?.value || "") || null), borderColor: "#ff5fb3", backgroundColor: "rgba(255,95,179,0.1)", fill: false, tension: 0.4, pointRadius: 5, pointBackgroundColor: "#ff5fb3" },
        ],
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: "#7d88a0" } } }, scales: { x: { ticks: { color: "#7d88a0", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } }, y: { ticks: { color: "#7d88a0", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } } } },
    });
  }, [ath1, ath2, ev, db]);

  return (
    <>
      <div className="compare-controls">
        <div className="cc-group"><label>Athlete 1</label><select value={ath1} onChange={(e) => setAth1(e.target.value)}><option value="">Select...</option>{athletes.map((a) => <option key={a} value={a}>{a}</option>)}</select></div>
        <div className="vs-badge">VS</div>
        <div className="cc-group"><label>Athlete 2</label><select value={ath2} onChange={(e) => setAth2(e.target.value)}><option value="">Select...</option>{athletes.map((a) => <option key={a} value={a}>{a}</option>)}</select></div>
        <div className="cc-group"><label>Event</label><select value={ev} onChange={(e) => setEv(e.target.value)}><option value="">Select...</option>{events.map((e) => <option key={e} value={e}>{e}</option>)}</select></div>
      </div>

      {ath1 && ath2 && ev ? (
        <div className="card">
          <div className="card-header"><div className="card-title">Performance Comparison — {ev}</div></div>
          <div style={{ position: "relative", width: "100%", height: 280 }}>
            <canvas id="cmp-chart" />
          </div>
        </div>
      ) : (
        <div className="empty"><div className="empty-icon">📊</div><h3>Select two athletes and an event</h3><p>Use the controls above to compare head-to-head.</p></div>
      )}
    </>
  );
}
