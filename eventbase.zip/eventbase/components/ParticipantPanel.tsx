"use client";
/**
 * ParticipantPanel — Multi-year participant tracking and tally.
 */

import type { Record } from "@/lib/types";
import { uniq, initials } from "@/lib/helpers";

interface ParticipantPanelProps { db: Record[]; }

export default function ParticipantPanel({ db }: ParticipantPanelProps) {
  const athletes = uniq(db, "athlete");

  if (!db.length) return (
    <div className="empty"><div className="empty-icon">👥</div><h3>No data yet</h3><p>Add records or import data to see participant tracking.</p></div>
  );

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Athlete</th>
            <th>Events</th>
            <th>Seasons</th>
            <th>Records</th>
          </tr>
        </thead>
        <tbody>
          {athletes.map((a) => {
            const recs  = db.filter((r) => r.athlete === a);
            const evts  = [...new Set(recs.map((r) => r.event))];
            const years = [...new Set(recs.map((r) => r.year))].sort();
            return (
              <tr key={a}>
                <td>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg,rgba(79,142,248,0.3),rgba(0,229,200,0.3))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: "var(--blue2)", flexShrink: 0 }}>{initials(a)}</div>
                    <strong>{a}</strong>
                  </div>
                </td>
                <td>{evts.join(", ")}</td>
                <td>{years.map((y) => <span key={y} className="year-chip" style={{ marginRight: 3 }}>{y}</span>)}</td>
                <td>{recs.length}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
