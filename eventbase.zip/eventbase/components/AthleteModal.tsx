"use client";
/**
 * AthleteModal — Detailed athlete profile with PBs, timeline, history, and chart.
 */

import { useEffect, useRef, useState } from "react";
import type { Record } from "@/lib/types";
import { initials, lowerIsBetter, isBetter, fmtDelta, rankBadge } from "@/lib/helpers";

interface AthleteModalProps {
  open: boolean;
  athlete: string | null;
  db: Record[];
  onClose: () => void;
}

type AthTab = "pb" | "timeline" | "history" | "chart";

export default function AthleteModal({ open, athlete, db, onClose }: AthleteModalProps) {
  const [tab, setTab] = useState<AthTab>("pb");
  const [chartEvent, setChartEvent] = useState("");
  const [chartType, setChartType]   = useState<"line" | "bar">("line");
  const chartRef = useRef<any>(null);

  const recs  = athlete ? db.filter((r) => r.athlete === athlete) : [];
  const evts  = [...new Set(recs.map((r) => r.event))];
  const yrs   = [...new Set(recs.map((r) => r.year))].sort((a, b) => a - b);

  useEffect(() => {
    if (tab === "chart" && open && evts.length) {
      const ev = chartEvent || evts[0];
      if (!chartEvent) setChartEvent(ev);
      setTimeout(() => buildChart(ev), 50);
    }
  }, [tab, chartEvent, chartType, open]);

  const buildChart = (ev: string) => {
    const Chart = (window as any).Chart;
    if (!Chart) return;
    const evRecs = recs.filter((r) => r.event === ev).sort((a, b) => a.year - b.year);
    if (!evRecs.length) return;
    if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; }
    const canvas = document.getElementById("ath-chart") as HTMLCanvasElement;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    chartRef.current = new Chart(ctx, {
      type: chartType,
      data: {
        labels: evRecs.map((r) => r.year),
        datasets: [{ data: evRecs.map((r) => parseFloat(r.value)), borderColor: "#4f8ef8", backgroundColor: chartType === "line" ? "rgba(79,142,248,0.1)" : evRecs.map((_, i) => ["#4f8ef8","#00e5c8","#ffb800","#00e676","#b06ef8"][i % 5]), fill: chartType === "line", tension: 0.4, pointRadius: 5, pointBackgroundColor: "#4f8ef8", borderRadius: 6, borderSkipped: false }],
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: "#7d88a0", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } }, y: { ticks: { color: "#7d88a0", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } } } },
    });
  };

  if (!open || !athlete) return null;

  // Personal Bests per event
  const pbTab = evts.map((ev) => {
    const evRecs = recs.filter((r) => r.event === ev).sort((a, b) => a.year - b.year);
    const unit   = evRecs[0]?.unit || "";
    const best   = evRecs.reduce((b, r) => (!b || isBetter(r.value, b.value, unit)) ? r : b, evRecs[0]);
    return { ev, evRecs, unit, best };
  });

  return (
    <div className="modal-overlay open" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box wide" style={{ maxWidth: 700 }}>
        <div className="modal-head">
          <div id="ath-modal-title" style={{ fontFamily: "var(--font-head)", fontSize: 16, fontWeight: 700 }}>{athlete}</div>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <div className="ath-modal-header">
          <div className="ath-modal-avatar">{initials(athlete)}</div>
          <div>
            <div className="ath-modal-name">{athlete}</div>
            <div className="ath-modal-meta">{evts.length} events · {yrs.length} seasons · {recs.length} records</div>
            <div className="ath-modal-stats">
              {evts.slice(0, 3).map((ev) => <span key={ev} className="ath-stat-pill"><b>{ev}</b></span>)}
              {evts.length > 3 && <span className="ath-stat-pill">+{evts.length - 3} more</span>}
            </div>
          </div>
        </div>

        <div className="tabs">
          {(["pb","timeline","history","chart"] as AthTab[]).map((t) => (
            <button key={t} className={`tab-btn ${tab === t ? "active" : ""}`} onClick={() => setTab(t)}>
              {t === "pb" ? "🏅 Personal Bests" : t === "timeline" ? "📈 Year Timeline" : t === "history" ? "📋 Full History" : "📊 Progress Chart"}
            </button>
          ))}
        </div>

        {/* PB Tab */}
        {tab === "pb" && (
          <div className="pb-list">
            {pbTab.map(({ ev, evRecs, unit, best }) => (
              <div key={ev} className="pb-item">
                <div className="pb-event">
                  <div className="pb-event-name">{ev}</div>
                  <div className="pb-event-type">{evRecs[0]?.eventType || ""}</div>
                  <div className="pb-years">{evRecs.map((r) => <span key={r.year} className="year-chip">{r.year}</span>)}</div>
                </div>
                <div className="pb-best">
                  <div className="pb-val">{best?.value} <span style={{ fontSize: 11, color: "var(--text3)" }}>{unit}</span></div>
                  <div className="pb-meta">{best?.year} · {best?.venue || "—"}<span className="pb-badge">PB</span></div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Timeline Tab */}
        {tab === "timeline" && (
          <div className="progress-timeline">
            {evts.map((ev) => {
              const evRecs = recs.filter((r) => r.event === ev).sort((a, b) => a.year - b.year);
              const vals   = evRecs.map((r) => parseFloat(r.value)).filter((v) => !isNaN(v));
              const minV   = Math.min(...vals), maxV = Math.max(...vals);
              const unit   = evRecs[0]?.unit || "";
              return (
                <div key={ev}>
                  <div style={{ fontWeight: 600, fontSize: 12, color: "var(--text2)", marginBottom: 6, marginTop: 10 }}>{ev}</div>
                  {evRecs.map((r, i) => {
                    const v  = parseFloat(r.value);
                    const pct = maxV === minV ? 50 : ((v - minV) / (maxV - minV)) * 100;
                    const prev = evRecs[i - 1];
                    const delta = prev ? v - parseFloat(prev.value) : NaN;
                    return (
                      <div key={r.year} className="pt-row">
                        <div className="pt-year">{r.year}</div>
                        <div className="pt-bar-wrap"><div className="pt-bar" style={{ width: `${pct}%`, background: "var(--grad-main)" }} /></div>
                        <div className="pt-value">{r.value} <span style={{ fontSize: 9, color: "var(--text3)" }}>{unit}</span></div>
                        <div className="pt-delta" dangerouslySetInnerHTML={{ __html: fmtDelta(delta, unit) }} />
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        )}

        {/* History Tab */}
        {tab === "history" && (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Event</th><th>Type</th><th>Year</th><th>Value</th><th>Unit</th><th>Rank</th><th>Venue</th></tr></thead>
              <tbody>
                {[...recs].sort((a, b) => b.year - a.year).map((r) => (
                  <tr key={r.id}>
                    <td><strong>{r.event}</strong></td>
                    <td><span className="tag tag-blue">{r.eventType || "Other"}</span></td>
                    <td><span className="year-chip">{r.year}</span></td>
                    <td>{r.value}</td>
                    <td>{r.unit || "—"}</td>
                    <td dangerouslySetInnerHTML={{ __html: r.rank ? rankBadge(r.rank) : "—" }} />
                    <td style={{ color: "var(--text2)" }}>{r.venue || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Chart Tab */}
        {tab === "chart" && (
          <div>
            <div style={{ marginBottom: 10, display: "flex", alignItems: "center", gap: 10 }}>
              <label style={{ fontSize: 11, color: "var(--text3)" }}>Event:</label>
              <select value={chartEvent} onChange={(e) => setChartEvent(e.target.value)} style={{ width: "auto", minWidth: 160 }}>
                {evts.map((ev) => <option key={ev} value={ev}>{ev}</option>)}
              </select>
              <label style={{ fontSize: 11, color: "var(--text3)", marginLeft: 10 }}>Chart:</label>
              <select value={chartType} onChange={(e) => setChartType(e.target.value as any)} style={{ width: "auto", minWidth: 100 }}>
                <option value="line">Line</option>
                <option value="bar">Bar</option>
              </select>
            </div>
            <div style={{ position: "relative", width: "100%", height: 260 }}>
              <canvas id="ath-chart" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
