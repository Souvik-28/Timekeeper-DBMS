"use client";
/**
 * AthletesPanel — Grid of athlete cards with event counts and trends.
 */

import { useState } from "react";
import type { Record } from "@/lib/types";
import { uniq, initials, isBetter, esc, eventLogoFallbackHTML } from "@/lib/helpers";

interface AthletesPanelProps {
  db: Record[];
  eventLogos: Record<string, { dataURL: string; color: string }>;
  onViewAthlete: (name: string) => void;
}

export default function AthletesPanel({ db, eventLogos, onViewAthlete }: AthletesPanelProps) {
  const [search, setSearch] = useState("");
  const [filterEvent, setFilterEvent] = useState("");

  const events = uniq(db, "event");
  const q = search.toLowerCase();

  let athletes = uniq(db, "athlete").filter((a) => !q || a.toLowerCase().includes(q));
  if (filterEvent) athletes = athletes.filter((a) => db.some((r) => r.athlete === a && r.event === filterEvent));

  const logoHTML = (evName: string, size = 22) => {
    const logo = eventLogos[evName];
    if (logo) return `<img src="${logo.dataURL}" style="width:${size}px;height:${size}px;object-fit:contain;border-radius:${Math.round(size * 0.2)}px;vertical-align:middle">`;
    return eventLogoFallbackHTML(evName, size);
  };

  return (
    <>
      <div className="search-row">
        <div className="search-wrap">
          <svg className="si" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input type="text" placeholder="Search athlete..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select value={filterEvent} onChange={(e) => setFilterEvent(e.target.value)}>
          <option value="">All events</option>
          {events.map((ev) => <option key={ev} value={ev}>{ev}</option>)}
        </select>
      </div>

      {athletes.length === 0 ? (
        <div className="empty"><div className="empty-icon">👥</div><h3>No athletes found</h3><p>Add records to see athlete profiles.</p></div>
      ) : (
        <div className="ath-grid">
          {athletes.map((a) => {
            const recs = db.filter((r) => r.athlete === a);
            const evts = [...new Set(recs.map((r) => r.event))];
            const yrs  = [...new Set(recs.map((r) => r.year))].sort((x, y) => x - y);
            let trendHtml = "";
            if (yrs.length >= 2) {
              const lastYrRecs = recs.filter((r) => r.year === yrs[yrs.length - 1]);
              const prevYrRecs = recs.filter((r) => r.year === yrs[yrs.length - 2]);
              const improved = lastYrRecs.some((lr) =>
                prevYrRecs.some((pr) => pr.event === lr.event && isBetter(lr.value, pr.value, lr.unit))
              );
              trendHtml = `<div class="ath-card-trend">${improved ? "▲ Improved vs last year" : "—"}</div>`;
            }
            return (
              <div key={a} className="ath-card" onClick={() => onViewAthlete(a)}>
                <div className="ath-avatar">{initials(a)}</div>
                <div className="ath-card-name">{a}</div>
                <div className="ath-card-meta">{recs.length} records · {evts.length} event{evts.length !== 1 ? "s" : ""}</div>
                <div className="ath-card-footer">{yrs.map((y) => <span key={y} className="year-chip">{y}</span>)}</div>
                <div style={{ display: "flex", gap: 4, marginTop: 8, flexWrap: "wrap" }}
                  dangerouslySetInnerHTML={{ __html: evts.map((ev) => logoHTML(ev, 22)).join("") }} />
                {trendHtml && <div dangerouslySetInnerHTML={{ __html: trendHtml }} />}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
