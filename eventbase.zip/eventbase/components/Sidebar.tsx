"use client";
/**
 * Sidebar — Navigation panel with logo, nav items, and mini stats.
 */

interface SidebarProps {
  activePanel: string;
  recordCount: number;
  logoCount: number;
  athleteCount: number;
  onNavigate: (panel: string) => void;
}

export default function Sidebar({
  activePanel,
  recordCount,
  logoCount,
  athleteCount,
  onNavigate,
}: SidebarProps) {
  const navItem = (
    id: string,
    label: string,
    icon: React.ReactNode,
    badge?: React.ReactNode
  ) => (
    <button
      className={`nav-item ${activePanel === id ? "active" : ""}`}
      onClick={() => onNavigate(id)}
    >
      <div className="nav-icon">{icon}</div>
      <span>{label}</span>
      {badge}
    </button>
  );

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon">🏆</div>
        <div className="logo-text">
          <div className="wordmark">
            Event<span>Base</span>
          </div>
          <div className="tagline">Sports Analytics</div>
        </div>
      </div>

      <div className="sidebar-section">Main</div>

      {navItem(
        "dashboard",
        "Dashboard",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="3" width="7" height="7" rx="1" />
          <rect x="14" y="3" width="7" height="7" rx="1" />
          <rect x="14" y="14" width="7" height="7" rx="1" />
          <rect x="3" y="14" width="7" height="7" rx="1" />
        </svg>
      )}

      {navItem(
        "events",
        "All Records",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z" />
        </svg>,
        <span className="nav-badge">{recordCount}</span>
      )}

      {navItem(
        "athletes",
        "Athletes",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="8" cy="7" r="4" />
          <path d="M2 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" />
          <path d="M17 11l2 2 4-4" />
        </svg>
      )}

      <div className="sidebar-section">Analysis</div>

      {navItem(
        "compare",
        "Year Compare",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 20V10M12 20V4M6 20v-6" />
        </svg>
      )}

      {navItem(
        "tally",
        "Tally & Search",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.35-4.35" />
        </svg>
      )}

      {navItem(
        "participant",
        "Participant Tally",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      )}

      <div className="sidebar-section">Branding</div>

      {navItem(
        "branding",
        "Event Logos",
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="3" width="18" height="18" rx="3" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <polyline points="21 15 16 10 5 21" />
        </svg>,
        <span
          className="nav-badge"
          style={{ background: "rgba(0,229,200,0.15)", color: "var(--cyan)" }}
        >
          {logoCount}
        </span>
      )}

      <div className="sidebar-bottom">
        <div className="stats-mini">
          <div className="stats-mini-item">
            <div className="stats-mini-val">{recordCount}</div>
            <div className="stats-mini-lbl">Records</div>
          </div>
          <div className="stats-mini-item">
            <div className="stats-mini-val">{athleteCount}</div>
            <div className="stats-mini-lbl">Athletes</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
