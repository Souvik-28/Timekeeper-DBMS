"use client";
/**
 * Topbar — Sticky top navigation bar with title, DB status, and action buttons.
 */

interface TopbarProps {
  title: string;
  subtitle: string;
  dbOnline: boolean;
  onAddRecord: () => void;
  onImport: () => void;
  onClearAll: () => void;
}

export default function Topbar({
  title,
  subtitle,
  dbOnline,
  onAddRecord,
  onImport,
  onClearAll,
}: TopbarProps) {
  return (
    <div className="topbar">
      <div className="topbar-title">
        {title} <small>{subtitle}</small>
      </div>

      <button
        className="db-status"
        title={dbOnline ? "IndexedDB connected" : "Using in-memory storage"}
      >
        <div className={`db-dot ${dbOnline ? "" : "offline"}`} />
        {dbOnline ? "DB Online" : "DB Offline"}
      </button>

      <button className="btn btn-ghost btn-sm" onClick={onClearAll}>
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          width="13"
          height="13"
        >
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6l-1 14H6L5 6" />
          <path d="M10 11v6M14 11v6" />
        </svg>
        Clear All
      </button>

      <button className="btn btn-ghost" onClick={onImport}>
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          width="14"
          height="14"
        >
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" y1="15" x2="12" y2="3" />
        </svg>
        Import Excel
      </button>

      <button className="btn btn-primary" onClick={onAddRecord}>
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          width="14"
          height="14"
        >
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
        Add Record
      </button>
    </div>
  );
}
