"use client";
/**
 * RecordsPanel — Browse, filter, and delete all performance records.
 */

import { useState } from "react";
import type { Record } from "@/lib/types";
import { uniq, esc, rankBadge, eventLogoFallbackHTML } from "@/lib/helpers";

interface RecordsPanelProps {
  db: Record[];
  eventLogos: Record<string, { dataURL: string; color: string }>;
  onDelete: (id: string) => void;
  onViewAthlete: (name: string) => void;
}

export default function RecordsPanel({ db, eventLogos, onDelete, onViewAthlete }: RecordsPanelProps) {
  const [search, setSearch] = useState("");
  const [year, setYear]     = useState("");
  const [type, setType]     = useState("");
  const [event, setEvent]   = useState("");

  const years  = uniq(db, "year");
  const types  = uniq(db, "eventType");
  const events = uniq(db, "event");

  const q = search.toLowerCase();
  const rows = db.filter(
    (r) =>
      (!q || r.athlete.toLowerCase().includes(q) || r.event.toLowerCase().includes(q) || (r.venue || "").toLowerCase().includes(q)) &&
      (!year  || String(r.year) === year) &&
      (!type  || r.eventType === type) &&
      (!event || r.event === event)
  );

  const logoHTML = (evName: string, size = 28) => {
    const logo = eventLogos[evName];
    if (logo) return `<img src="${logo.dataURL}" style="width:${size}px;height:${size}px;object-fit:contain;border-radius:${Math.round(size * 0.2)}px;vertical-align:middle">`;
    return eventLogoFallbackHTML(evName, size);
  };

  return (
    <>
      <div className="search-row">
        <div className="search-wrap">
          <svg className="si" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input type="text" placeholder="Search athlete, event, venue..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select value={year} onChange={(e) => setYear(e.target.value)}>
          <option value="">All years</option>
          {years.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">All types</option>
          {types.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={event} onChange={(e) => setEvent(e.target.value)}>
          <option value="">All events</option>
          {events.map((ev) => <option key={ev} value={ev}>{ev}</option>)}
        </select>
      </div>

      {rows.length === 0 ? (
        <div className="empty"><div className="empty-icon">🏆</div><h3>No records found</h3><p>Try different filters or add data.</p></div>
      ) : (
        <>
          <p style={{ fontSize: 11.5, color: "var(--text3)", marginBottom: 10 }}>{rows.length} record{rows.length !== 1 ? "s" : ""} found</p>
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th></th><th>Athlete</th><th>Event</th><th>Type</th><th>Year</th><th>Value</th><th>Unit</th><th>Rank</th><th>Venue</th><th></th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td style={{ width: 36, padding: "6px 8px" }} dangerouslySetInnerHTML={{ __html: logoHTML(r.event, 28) }} />
                    <td className="td-athlete" onClick={() => onViewAthlete(r.athlete)}>{r.athlete}</td>
                    <td>{r.event}</td>
                    <td><span className="tag tag-blue">{r.eventType || "Other"}</span></td>
                    <td><span className="year-chip">{r.year}</span></td>
                    <td><strong>{r.value}</strong></td>
                    <td>{r.unit || "—"}</td>
                    <td dangerouslySetInnerHTML={{ __html: r.rank ? rankBadge(r.rank) : "—" }} />
                    <td style={{ color: "var(--text2)" }}>{r.venue || "—"}</td>
                    <td>
                      <button className="del-btn" onClick={() => { if (confirm("Delete this record?")) onDelete(r.id); }}>✕</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  );
}
