"use client";
/**
 * ImportModal — Modal for importing Excel/CSV performance data.
 * Uses SheetJS (xlsx) loaded via CDN for file parsing.
 */

import { useState, useRef } from "react";
import type { Record } from "@/lib/types";
import { normaliseRows, parseCSV, uid } from "@/lib/helpers";

interface ImportModalProps {
  open: boolean;
  onClose: () => void;
  onImport: (records: Record[]) => void;
}

export default function ImportModal({ open, onClose, onImport }: ImportModalProps) {
  const [preview, setPreview] = useState<Omit<Record, "id">[]>([]);
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    const ext = file.name.split(".").pop()?.toLowerCase();
    const reader = new FileReader();
    if (ext === "csv") {
      reader.onload = (e) => {
        const rows = parseCSV(e.target?.result as string);
        setPreview(normaliseRows(rows));
      };
      reader.readAsText(file);
    } else {
      reader.onload = (e) => {
        const XLSX = (window as any).XLSX;
        if (!XLSX) return;
        const wb = XLSX.read(e.target?.result, { type: "array", cellText: true, cellDates: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { defval: "", raw: false });
        setPreview(normaliseRows(rows));
      };
      reader.readAsArrayBuffer(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) processFile(f);
  };

  const handleImport = () => {
    const records: Record[] = preview.map((r) => ({ ...r, id: uid() }));
    onImport(records);
    setPreview([]);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="modal-overlay open" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box wide">
        <div className="modal-head">
          <div>
            <h2>Import Excel / CSV</h2>
            <p>Required: Athlete, Event, Year, Value — Optional: EventType, Unit, Rank, Venue, Notes</p>
          </div>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <div style={{ fontSize: 12, color: "var(--text2)", background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: "var(--r)", padding: "10px 12px", marginBottom: 14, lineHeight: 1.7 }}>
          Required columns: <code>Athlete</code> <code>Event</code> <code>Year</code> <code>Value</code>
          &nbsp;·&nbsp; Optional: <code>EventType</code> <code>Unit</code> <code>Rank</code> <code>Venue</code> <code>Notes</code>
        </div>

        <div
          className={`upload-zone ${dragging ? "drag" : ""}`}
          onClick={() => fileRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
        >
          <div className="uz-icon">📊</div>
          <h3>Click to choose file or drag &amp; drop</h3>
          <p>Your data stays private — processed entirely in your browser</p>
          <div className="ext-badges">
            <span className="ext-badge">.xlsx</span>
            <span className="ext-badge">.xls</span>
            <span className="ext-badge">.csv</span>
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          style={{ display: "none" }}
          onChange={(e) => { const f = e.target.files?.[0]; if (f) processFile(f); }}
        />

        {preview.length > 0 && (
          <div style={{ marginTop: 12 }}>
            <div className="import-ok">
              ✓ {preview.length} record{preview.length !== 1 ? "s" : ""} ready to import
            </div>
            <div className="table-wrap" style={{ maxHeight: 200, overflowY: "auto" }}>
              <table>
                <thead>
                  <tr>
                    <th>Athlete</th><th>Event</th><th>Year</th>
                    <th>Value</th><th>Unit</th><th>Rank</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.slice(0, 10).map((r, i) => (
                    <tr key={i}>
                      <td>{r.athlete}</td><td>{r.event}</td>
                      <td>{r.year}</td><td>{r.value}</td>
                      <td>{r.unit || "—"}</td><td>{r.rank || "—"}</td>
                    </tr>
                  ))}
                  {preview.length > 10 && (
                    <tr>
                      <td colSpan={6} style={{ color: "var(--text3)", textAlign: "center" }}>
                        ... and {preview.length - 10} more
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <hr />
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          {preview.length > 0 && (
            <button className="btn btn-success" onClick={handleImport}>
              ✓ Import {preview.length} Records
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
